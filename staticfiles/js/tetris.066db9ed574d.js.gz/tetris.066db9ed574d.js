    a = document.getElementById('blah')
    console.log('a')
    console.log("HELLO WORLD")
    alert("HELLO")